package realstaqABC;

import static io.restassured.RestAssured.given;
import org.testng.annotations.Test;
import io.restassured.RestAssured;


public class TestSuite{

	// POSITIVE TESTS

	//Verify that Houses in New York within proper price range are displayed
	@Test
	public void TestCase1()
	
	{
		
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("price_gte", "200000").queryParam("price_lte", "500000").queryParam("city", "New+York").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
    }
		
	//Verify that Houses in Austin with higher price then selected are displayed
	@Test
	public void  TestCase2() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("price_gte", "450000").queryParam("city", "Austin").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}

	//Verify that a House with selected ID is displayed
	@Test 
	public void  TestCase3() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("id", "4b06aeca-2977-4df1-9821-4efa40842e5f").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}	

	//Verify that Houses in Austin with specific number bedrooms are displayed
	@Test 
	public void  TestCase4() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("bedrooms", "4").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}	

	//Verify that Houses in state of Texas are displayed
	@Test 
	public void  TestCase5() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("state", "TX").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}

	//NEGATIVE TESTS

	//Verify that status code 404 is displayed for the wrong route
	@Test
	public void TestCase6()
	
	{
		
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("price_gte", "200000").queryParam("price_lte", "500000").queryParam("city", "New+York").header("Content-Type", "application/json")
		.when().get("hou")
		.then().assertThat().statusCode(404);
		
    }
		
	//Verify that no houses are displayed for the wrong price range
	@Test
	public void  TestCase7() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("price_gte", "400000").queryParam("price_lte", "0").queryParam("city", "Austin").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}

	//Verify that no houses are displayed for the wrong house id
	@Test 
	public void  TestCase8() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("id", "4b06aeca").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}	

	//Verify that no houses are displayed with 200 bedrooms
	@Test 
	public void  TestCase9() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("bedrooms", "400").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}	

	//Verify that no houses are displayed for the state of Wyoming
	@Test 
	public void  TestCase10() {
		RestAssured.baseURI="http://localhost:3000";
		
		given().log().all().queryParam("state", "WY").header("Content-Type", "application/json")
		.when().get("houses")
		.then().assertThat().statusCode(200);
		
	}

}