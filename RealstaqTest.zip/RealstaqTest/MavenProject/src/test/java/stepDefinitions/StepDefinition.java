package stepDefinitions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

public class StepDefinition {

	 	@Given("^add house Payload$")
	    public void add_house_payload() throws Throwable {
	 		RestAssured.baseURI="http://localhost:3000";
	        throw new PendingException();
	    }

	    @When("^user calls API with GET http request$")
	    public void user_calls_api_with_get_http_request() throws Throwable {
	        throw new PendingException();
	    }

	    @Then("^the API call is success with status code 200$")
	    public void the_api_call_is_success_with_status_code_200() throws Throwable {
	        throw new PendingException();
	    }

	    @And("^status in response body is OK$")
	    public void status_in_response_body_is_ok() throws Throwable {
	        throw new PendingException();
	    }
	
}
